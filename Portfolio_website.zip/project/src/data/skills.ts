import { Skill } from '../types';

const skills: Skill[] = [
  // Programming Languages
  {
    id: 1,
    name: 'C++',
    level: 90,
    category: 'frontend'
  },
  {
    id: 2,
    name: 'Java',
    level: 85,
    category: 'frontend'
  },
  {
    id: 3,
    name: 'Python',
    level: 85,
    category: 'frontend'
  },
  {
    id: 4,
    name: 'C',
    level: 80,
    category: 'frontend'
  },
  {
    id: 5,
    name: 'R',
    level: 75,
    category: 'frontend'
  },
  
  // Libraries/Frameworks
  {
    id: 6,
    name: 'NumPy',
    level: 85,
    category: 'backend'
  },
  {
    id: 7,
    name: 'Pandas',
    level: 85,
    category: 'backend'
  },
  {
    id: 8,
    name: 'Matplotlib',
    level: 80,
    category: 'backend'
  },
  {
    id: 9,
    name: 'Spring Boot',
    level: 75,
    category: 'backend'
  },
  {
    id: 10,
    name: 'React',
    level: 70,
    category: 'backend'
  },
  {
    id: 11,
    name: 'JavaFX',
    level: 70,
    category: 'backend'
  },

  // Tools
  {
    id: 12,
    name: 'RStudio',
    level: 85,
    category: 'tools'
  },
  {
    id: 13,
    name: 'Jupyter Notebook',
    level: 90,
    category: 'tools'
  },
  {
    id: 14,
    name: 'Git/GitHub',
    level: 85,
    category: 'tools'
  },
  {
    id: 15,
    name: 'VS Code',
    level: 90,
    category: 'tools'
  },
  {
    id: 16,
    name: 'Eclipse',
    level: 80,
    category: 'tools'
  },

  // Databases
  {
    id: 17,
    name: 'MySQL',
    level: 85,
    category: 'other'
  },
  {
    id: 18,
    name: 'SQLite',
    level: 80,
    category: 'other'
  },
  {
    id: 19,
    name: 'MongoDB',
    level: 75,
    category: 'other'
  }
];

export default skills;