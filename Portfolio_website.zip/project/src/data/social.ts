import { SocialLink } from '../types';

const socialLinks: SocialLink[] = [
  {
    name: 'GitHub',
    url: 'https://github.com/yourusername',
    icon: 'github'
  },
  {
    name: 'LinkedIn',
    url: 'https://linkedin.com/in/yourusername',
    icon: 'linkedin'
  },
  {
    name: 'HackerRank',
    url: 'https://www.hackerrank.com/yourusername',
    icon: 'code'
  },
  {
    name: 'Email',
    url: 'mailto:abhieshek11@gmail.com',
    icon: 'mail'
  }
];

export default socialLinks;