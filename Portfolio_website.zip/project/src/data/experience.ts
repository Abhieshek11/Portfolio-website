import { Experience, Education } from '../types';

export const experiences: Experience[] = [
  {
    id: 1,
    company: 'Self-Directed Projects',
    position: 'Data Analysis & Development',
    duration: '2022 - Present',
    description: [
      'Developed Facialytics, a face recognition system using Python, OpenCV, and deep learning models',
      'Integrated Flask web interface for real-time face recognition and attendance tracking',
      'Implemented secure data storage using SQLite database',
      'Created responsive front-end interface using HTML/CSS and JavaScript'
    ],
    technologies: ['Python', 'OpenCV', 'Flask', 'SQLite', 'HTML/CSS', 'JavaScript']
  }
];

export const education: Education[] = [
  {
    id: 1,
    institution: 'Greater Noida Institute of Technology (GNIOT)',
    degree: 'B.Tech in Computer Science with Artificial Intelligence',
    duration: '2022 - 2026',
    description: 'Currently pursuing Bachelor\'s degree with focus on AI and Data Analysis'
  },
  {
    id: 2,
    institution: 'INDRAPRASTHA CONVENT SR.SEC.SCHOOL',
    degree: 'Class XII - Science Stream (Non-Medical)',
    duration: '2021 - 2022',
    description: 'Completed senior secondary education with focus on Science and Mathematics'
  },
  {
    id: 3,
    institution: 'Indraprastha Modern School',
    degree: 'Class X',
    duration: '2019 - 2020',
    description: 'Completed secondary education with strong academic foundation'
  }
];