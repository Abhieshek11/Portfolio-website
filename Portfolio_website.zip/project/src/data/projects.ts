import { Project } from '../types';

const projects: Project[] = [
  {
    id: 1,
    title: 'E-Commerce Platform',
    description: 'A fully functional e-commerce platform with product management, shopping cart, and payment integration. Built with React, Node.js, and MongoDB.',
    image: 'https://images.pexels.com/photos/5632402/pexels-photo-5632402.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    tags: ['React', 'Node.js', 'MongoDB', 'Express', 'Redux'],
    githubUrl: 'https://github.com/yourusername/e-commerce',
    liveUrl: 'https://e-commerce-demo.com',
    featured: true
  },
  {
    id: 2,
    title: 'AI Image Generator',
    description: 'An AI-powered image generation tool that creates unique images based on text prompts. Integrated with OpenAI API and built with Next.js.',
    image: 'https://images.pexels.com/photos/8386434/pexels-photo-8386434.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    tags: ['Next.js', 'TypeScript', 'OpenAI', 'Tailwind CSS'],
    githubUrl: 'https://github.com/yourusername/ai-image-generator',
    liveUrl: 'https://ai-image-demo.com',
    featured: true
  },
  {
    id: 3,
    title: 'Task Management App',
    description: 'A productivity application for task management with features like drag-and-drop, filtering, and team collaboration.',
    image: 'https://images.pexels.com/photos/6956903/pexels-photo-6956903.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    tags: ['React', 'Firebase', 'Tailwind CSS', 'Drag & Drop'],
    githubUrl: 'https://github.com/yourusername/task-manager',
    liveUrl: 'https://task-manager-demo.com',
    featured: false
  },
  {
    id: 4,
    title: 'Weather Dashboard',
    description: 'A real-time weather application showing current conditions and forecasts using the OpenWeather API.',
    image: 'https://images.pexels.com/photos/1118873/pexels-photo-1118873.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    tags: ['JavaScript', 'API Integration', 'CSS3', 'Responsive Design'],
    githubUrl: 'https://github.com/yourusername/weather-dashboard',
    liveUrl: 'https://weather-dashboard-demo.com',
    featured: false
  },
  {
    id: 5,
    title: 'Fitness Tracker',
    description: 'A mobile-first application for tracking workouts, nutrition, and fitness goals with visualization charts.',
    image: 'https://images.pexels.com/photos/841130/pexels-photo-841130.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    tags: ['React Native', 'Redux', 'Chart.js', 'Firebase'],
    githubUrl: 'https://github.com/yourusername/fitness-tracker',
    featured: false
  },
  {
    id: 6,
    title: 'Personal Blog',
    description: 'A blog platform built with Gatsby and Markdown for publishing technical articles and tutorials.',
    image: 'https://images.pexels.com/photos/3059748/pexels-photo-3059748.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    tags: ['Gatsby', 'GraphQL', 'Markdown', 'Netlify CMS'],
    githubUrl: 'https://github.com/yourusername/personal-blog',
    liveUrl: 'https://blog-demo.com',
    featured: false
  }
];

export default projects;