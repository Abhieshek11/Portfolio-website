import React from 'react';
import { Github, Linkedin, Twitter, Mail, Heart } from 'lucide-react';
import socialLinks from '../data/social';

const Footer: React.FC = () => {
  const iconMap: Record<string, React.ReactNode> = {
    github: <Github size={18} />,
    linkedin: <Linkedin size={18} />,
    twitter: <Twitter size={18} />,
    mail: <Mail size={18} />
  };

  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-dark-900 text-white py-12">
      <div className="container mx-auto px-4 md:px-8">
        <div className="flex flex-col items-center">
          <a 
            href="#home" 
            className="text-2xl font-bold mb-6"
          >
            yourname
            <span className="text-primary-500">.</span>
            <span className="text-secondary-500">dev</span>
          </a>
          
          <div className="flex gap-6 mb-8">
            {socialLinks.map((social, index) => (
              <a
                key={index}
                href={social.url}
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 bg-dark-800 hover:bg-primary-500 text-white rounded-full transition-colors"
                aria-label={social.name}
              >
                {iconMap[social.icon]}
              </a>
            ))}
          </div>
          
          <div className="w-full max-w-2xl mx-auto h-px bg-dark-700 mb-8"></div>
          
          <div className="flex flex-col sm:flex-row justify-center items-center gap-2 sm:gap-6 text-dark-400 text-sm">
            <div className="flex items-center">
              <span className="mr-1">Made with</span>
              <Heart size={14} className="text-red-500 mx-1" />
              <span>by Your Name</span>
            </div>
            <span className="hidden sm:inline">•</span>
            <span>&copy; {currentYear} All Rights Reserved</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;