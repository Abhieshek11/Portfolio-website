import React from 'react';
import { motion } from 'framer-motion';
import { Calendar, Award } from 'lucide-react';
import { experiences, education } from '../data/experience';

const ExperienceSection: React.FC = () => {
  return (
    <section id="experience" className="py-20 bg-gray-50 dark:bg-dark-900">
      <div className="container mx-auto px-4 md:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold text-dark-900 dark:text-white mb-4">
            Work <span className="text-primary-500">Experience</span>
          </h2>
          <div className="w-24 h-1 bg-primary-500 mx-auto"></div>
        </motion.div>

        <div className="max-w-4xl mx-auto">
          <div className="relative">
            {/* Timeline Line */}
            <div className="absolute left-0 md:left-1/2 transform md:-translate-x-1/2 top-0 bottom-0 w-1 bg-gray-200 dark:bg-dark-700"></div>

            {/* Work Experience Timeline */}
            {experiences.map((exp, index) => (
              <motion.div 
                key={exp.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.2 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className={`relative flex items-center md:justify-between mb-16 ${
                  index % 2 === 0 ? 'md:flex-row-reverse' : ''
                }`}
              >
                {/* Timeline Circle */}
                <div className="absolute left-0 md:left-1/2 transform -translate-x-1/2 w-5 h-5 rounded-full bg-primary-500 border-4 border-white dark:border-dark-900 z-10"></div>
                
                {/* Content Box */}
                <div className={`ml-8 md:ml-0 md:w-5/12 ${
                  index % 2 === 0 ? 'md:mr-auto md:text-right' : 'md:ml-auto'
                }`}>
                  <div className="bg-white dark:bg-dark-800 rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
                    <div className="flex items-center gap-2 text-primary-500 mb-2">
                      <Calendar size={16} className={index % 2 === 0 ? 'md:order-last' : ''} />
                      <span className="text-sm font-medium">{exp.duration}</span>
                    </div>
                    
                    <h3 className="text-xl font-bold text-dark-900 dark:text-white mb-1">
                      {exp.position}
                    </h3>
                    <h4 className="text-lg text-primary-600 dark:text-primary-400 font-medium mb-4">
                      {exp.company}
                    </h4>
                    
                    <ul className={`text-dark-700 dark:text-dark-300 mb-4 list-disc ${
                      index % 2 === 0 ? 'md:ml-auto md:mr-6' : 'ml-6'
                    }`}>
                      {exp.description.map((item, i) => (
                        <li key={i} className="mb-2">{item}</li>
                      ))}
                    </ul>
                    
                    <div className="flex flex-wrap gap-2">
                      {exp.technologies.map((tech, i) => (
                        <span 
                          key={i} 
                          className="px-3 py-1 text-xs font-medium bg-gray-100 dark:bg-dark-700 text-dark-700 dark:text-dark-300 rounded-full"
                        >
                          {tech}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.6 }}
          className="text-center mt-24 mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold text-dark-900 dark:text-white mb-4">
            <span className="text-primary-500">Education</span>
          </h2>
          <div className="w-24 h-1 bg-primary-500 mx-auto"></div>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {education.map((edu, index) => (
            <motion.div
              key={edu.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.2 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="bg-white dark:bg-dark-800 rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow"
            >
              <div className="flex items-center gap-2 text-primary-500 mb-2">
                <Award size={18} />
                <span className="text-sm font-medium">{edu.duration}</span>
              </div>
              
              <h3 className="text-xl font-bold text-dark-900 dark:text-white mb-1">
                {edu.degree}
              </h3>
              <h4 className="text-lg text-primary-600 dark:text-primary-400 font-medium mb-4">
                {edu.institution}
              </h4>
              
              <p className="text-dark-700 dark:text-dark-300">
                {edu.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ExperienceSection;