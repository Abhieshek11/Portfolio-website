import React, { useState } from 'react';
import { motion } from 'framer-motion';
import ProjectCard from './ProjectCard';
import projects from '../data/projects';

const ProjectsSection: React.FC = () => {
  const [filter, setFilter] = useState<'all' | 'featured'>('all');
  
  const filteredProjects = filter === 'all' 
    ? projects 
    : projects.filter(project => project.featured);

  return (
    <section id="projects" className="py-20 bg-white dark:bg-dark-950">
      <div className="container mx-auto px-4 md:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold text-dark-900 dark:text-white mb-4">
            My <span className="text-primary-500">Projects</span>
          </h2>
          <div className="w-24 h-1 bg-primary-500 mx-auto mb-8"></div>
          <p className="text-dark-700 dark:text-dark-300 max-w-2xl mx-auto">
            Here are some of the projects I've worked on. Each project represents my skills and experiences
            in different technologies and problem domains.
          </p>
        </motion.div>

        <div className="flex justify-center gap-4 mb-12">
          <button
            onClick={() => setFilter('all')}
            className={`
              py-2 px-6 rounded-full text-sm font-medium transition-all
              ${filter === 'all' 
                ? 'bg-primary-500 text-white shadow-md' 
                : 'bg-white dark:bg-dark-800 text-dark-700 dark:text-dark-300 hover:bg-gray-100 dark:hover:bg-dark-700'}
            `}
          >
            All Projects
          </button>
          <button
            onClick={() => setFilter('featured')}
            className={`
              py-2 px-6 rounded-full text-sm font-medium transition-all
              ${filter === 'featured' 
                ? 'bg-primary-500 text-white shadow-md' 
                : 'bg-white dark:bg-dark-800 text-dark-700 dark:text-dark-300 hover:bg-gray-100 dark:hover:bg-dark-700'}
            `}
          >
            Featured
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProjects.map((project, index) => (
            <ProjectCard key={project.id} project={project} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default ProjectsSection;