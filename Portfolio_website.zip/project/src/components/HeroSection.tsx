import React from 'react';
import { motion } from 'framer-motion';
import { ChevronDown, Github, Linkedin, Twitter, Mail } from 'lucide-react';
import { TypeAnimation } from 'react-type-animation';
import socialLinks from '../data/social';

const HeroSection: React.FC = () => {
  const iconMap: Record<string, React.ReactNode> = {
    github: <Github size={20} />,
    linkedin: <Linkedin size={20} />,
    twitter: <Twitter size={20} />,
    mail: <Mail size={20} />
  };

  return (
    <section id="home" className="min-h-screen flex items-center justify-center pt-16 relative overflow-hidden bg-gray-50 dark:bg-dark-900">
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-br from-primary-50/30 to-secondary-50/30 dark:from-primary-900/10 dark:to-secondary-900/10"></div>
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-primary-500 via-secondary-500 to-primary-500 bg-size-200 animate-gradient"></div>
      </div>
      
      <div className="container mx-auto px-4 md:px-8 relative z-10">
        <div className="text-center max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="mb-8"
          >
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-dark-900 dark:text-white mb-4">
              Hi, I'm <span className="text-primary-500">Your Name</span>
            </h1>
            <h2 className="text-2xl md:text-3xl text-dark-600 dark:text-dark-300 font-medium h-12">
              <TypeAnimation
                sequence={[
                  'Frontend Developer',
                  1000,
                  'UI/UX Enthusiast',
                  1000,
                  'React Specialist',
                  1000,
                  'Problem Solver',
                  1000
                ]}
                wrapper="span"
                speed={40}
                repeat={Infinity}
              />
            </h2>
          </motion.div>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-lg md:text-xl text-dark-700 dark:text-dark-300 mb-8 max-w-3xl mx-auto"
          >
            I create modern, responsive web applications with a focus on user experience.
            Let's work together to bring your ideas to life!
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="flex flex-col sm:flex-row justify-center gap-4 mb-12"
          >
            <a
              href="#contact"
              className="py-3 px-8 bg-primary-600 hover:bg-primary-700 text-white rounded-full transition-colors shadow-lg hover:shadow-xl transform hover:-translate-y-1"
            >
              Let's Connect
            </a>
            <a
              href="#projects"
              className="py-3 px-8 bg-white dark:bg-dark-800 text-dark-700 dark:text-dark-200 hover:bg-gray-100 dark:hover:bg-dark-700 rounded-full border border-dark-200 dark:border-dark-700 transition-colors shadow-lg hover:shadow-xl transform hover:-translate-y-1"
            >
              View Projects
            </a>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.6 }}
            className="flex justify-center gap-6 mb-12"
          >
            {socialLinks.map((social, index) => (
              <a
                key={index}
                href={social.url}
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 bg-white dark:bg-dark-800 text-dark-600 dark:text-dark-300 rounded-full hover:text-primary-500 dark:hover:text-primary-400 hover:shadow-lg transition-all transform hover:-translate-y-1"
                aria-label={social.name}
              >
                {iconMap[social.icon]}
              </a>
            ))}
          </motion.div>
        </div>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ 
          duration: 0.8, 
          delay: 1.2,
          repeat: Infinity,
          repeatType: "reverse",
          repeatDelay: 0.5
        }}
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
      >
        <a href="#about" className="flex flex-col items-center text-dark-500 dark:text-dark-400 hover:text-primary-500 dark:hover:text-primary-400 transition-colors">
          <span className="text-sm mb-2">Scroll Down</span>
          <ChevronDown size={24} />
        </a>
      </motion.div>
    </section>
  );
};

export default HeroSection;